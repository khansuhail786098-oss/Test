// Ye file Telegram Bot API ke saath baat karti hai:
// 1. sendPhotoToTelegram -> photo ko private channel me bhejta hai, file_id return karta hai
// 2. getTelegramFileUrl  -> file_id se ek direct downloadable URL nikalta hai (app isi se image dikhata hai)
const fetch = require('node-fetch');
const FormData = require('form-data');
const fs = require('fs');

const BOT_TOKEN = process.env.BOT_TOKEN;
const CHANNEL_ID = process.env.CHANNEL_ID;

const API_BASE = `https://api.telegram.org/bot${BOT_TOKEN}`;
const FILE_BASE = `https://api.telegram.org/file/bot${BOT_TOKEN}`;

// Telegram ka file_path kuch der (~1 hour) tak valid rehta hai, isliye cache kar lete hain
// taaki har request pe getFile na karna pade.
const fileUrlCache = new Map();
const CACHE_TTL_MS = 1000 * 60 * 50;

async function sendPhotoToTelegram(localFilePath, caption) {
  const form = new FormData();
  form.append('chat_id', CHANNEL_ID);
  form.append('caption', caption || '');
  form.append('photo', fs.createReadStream(localFilePath));

  const response = await fetch(`${API_BASE}/sendPhoto`, {
    method: 'POST',
    body: form,
  });
  const data = await response.json();

  if (!data.ok) {
    throw new Error(`Telegram sendPhoto error: ${JSON.stringify(data)}`);
  }

  // Telegram ek hi photo ke multiple sizes bhejta hai, sabse badi wali file_id lete hain
  const sizes = data.result.photo;
  const largest = sizes[sizes.length - 1];
  return largest.file_id;
}

async function getTelegramFileUrl(fileId) {
  const cached = fileUrlCache.get(fileId);
  if (cached && Date.now() - cached.time < CACHE_TTL_MS) {
    return cached.url;
  }

  const response = await fetch(`${API_BASE}/getFile?file_id=${fileId}`);
  const data = await response.json();

  if (!data.ok) {
    throw new Error(`Telegram getFile error: ${JSON.stringify(data)}`);
  }

  const url = `${FILE_BASE}/${data.result.file_path}`;
  fileUrlCache.set(fileId, { url, time: Date.now() });
  return url;
}

module.exports = { sendPhotoToTelegram, getTelegramFileUrl };
