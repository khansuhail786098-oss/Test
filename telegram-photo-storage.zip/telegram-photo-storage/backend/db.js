// Halka sa local database — sirf ek file (storage.db), koi cloud account nahi chahiye.
// Ye sirf Telegram file_id aur uska metadata (caption, order) store karta hai.
const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'storage.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS photos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id TEXT NOT NULL,
    caption TEXT,
    position INTEGER DEFAULT 0,
    created_at INTEGER
  )
`);

module.exports = db;
