require('dotenv').config();
const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const db = require('./db');
const { sendPhotoToTelegram, getTelegramFileUrl } = require('./telegramBot');

const app = express();
app.use(cors());
app.use(express.json());

const upload = multer({ dest: path.join(__dirname, 'tmp_uploads') });

// ---------------------------------------------------------------------------
// ADMIN ROUTES — Web admin panel inhe use karta hai
// ---------------------------------------------------------------------------

// Naya photo upload: admin panel se file aati hai -> Telegram channel me jaati hai -> file_id save hota hai
app.post('/api/admin/upload', upload.single('photo'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No photo uploaded' });
    const { caption, position } = req.body;

    const fileId = await sendPhotoToTelegram(req.file.path, caption);
    fs.unlink(req.file.path, () => {}); // temp file delete kar do

    const stmt = db.prepare(
      'INSERT INTO photos (file_id, caption, position, created_at) VALUES (?, ?, ?, ?)'
    );
    const info = stmt.run(fileId, caption || '', Number(position) || 0, Date.now());

    res.json({ success: true, id: info.lastInsertRowid, file_id: fileId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Upload failed', details: err.message });
  }
});

// Sab photos ki list (admin dashboard ke liye, preview URL ke saath)
app.get('/api/admin/photos', async (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM photos ORDER BY position ASC, created_at DESC').all();
    const withUrls = await Promise.all(
      rows.map(async (row) => ({ ...row, url: await getTelegramFileUrl(row.file_id) }))
    );
    res.json(withUrls);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch photos' });
  }
});

// Caption/position update
app.put('/api/admin/photos/:id', (req, res) => {
  const { caption, position } = req.body;
  db.prepare('UPDATE photos SET caption = ?, position = ? WHERE id = ?').run(
    caption, Number(position) || 0, req.params.id
  );
  res.json({ success: true });
});

// Photo hata do (sirf apne index se — Telegram channel se nahi, wo backup ke roop me rehne dena behtar hai)
app.delete('/api/admin/photos/:id', (req, res) => {
  db.prepare('DELETE FROM photos WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ---------------------------------------------------------------------------
// PUBLIC ROUTE — Android app isi endpoint ko call karta hai
// ---------------------------------------------------------------------------
app.get('/api/photos', async (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM photos ORDER BY position ASC, created_at DESC').all();
    const withUrls = await Promise.all(
      rows.map(async (row) => ({
        id: row.id,
        caption: row.caption,
        url: await getTelegramFileUrl(row.file_id),
      }))
    );
    res.json(withUrls);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch photos' });
  }
});

// Admin panel ki static files serve karo -> http://localhost:3000/admin
app.use('/admin', express.static(path.join(__dirname, '..', 'admin-panel')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server chal raha hai: http://localhost:${PORT}`));
