package com.example.photostorage

data class Photo(
    val id: Int,
    val caption: String?,
    val url: String
)
