package com.example.photostorage

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

interface ApiService {
    @GET("api/photos")
    fun getPhotos(): Call<List<Photo>>
}

object ApiClient {
    // 10.0.2.2 = emulator ke liye "localhost". Real phone pe test karte waqt
    // apne backend ka actual IP/domain daalo, e.g. "http://192.168.1.5:3000/"
    private const val BASE_URL = "http://10.0.2.2:3000/"

    val service: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
