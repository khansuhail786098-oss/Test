package com.example.photostorage

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.photoRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        loadPhotos(recyclerView)
    }

    private fun loadPhotos(recyclerView: RecyclerView) {
        ApiClient.service.getPhotos().enqueue(object : Callback<List<Photo>> {
            override fun onResponse(call: Call<List<Photo>>, response: Response<List<Photo>>) {
                val photos = response.body() ?: emptyList()
                recyclerView.adapter = PhotoAdapter(photos)
            }

            override fun onFailure(call: Call<List<Photo>>, t: Throwable) {
                Toast.makeText(
                    this@MainActivity,
                    "Photos load nahi ho payi: ${t.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        })
    }
}
