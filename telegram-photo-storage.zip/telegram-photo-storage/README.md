# Telegram-based Photo Storage — Full Example

Isme 3 parts hain:
- `backend/` — Node.js server jo Telegram bot se baat karta hai aur SQLite me index rakhta hai
- `admin-panel/` — Web panel jaha se photo upload karoge
- `android-app/` — Android Studio project (Kotlin) jo photos ko fetch karke dikhata hai

Koi Firebase/MongoDB nahi hai. Storage = Telegram channel. Index = ek chhoti si SQLite file.

---

## Step 1 — Telegram Bot Banao

1. Telegram me **@BotFather** ko message karo → `/newbot` → naam do → tumhe ek **BOT_TOKEN** milega
2. Ek **private channel** banao (photos store karne ke liye)
3. Us bot ko channel me **admin** banake add karo
4. Channel ki ID nikaalne ke liye:
   - Channel me koi bhi message forward karo apne bot ko **@userinfobot** ya **@getidsbot** jaisa koi utility bot use karke, ya
   - Bot ko channel me ek baar message bhejwao aur `https://api.telegram.org/bot<TOKEN>/getUpdates` khol ke `chat.id` dekho
   - Channel ID kuch aisi dikhegi: `-1001234567890`

---

## Step 2 — Backend Chalao

```bash
cd backend
npm install
cp .env.example .env
```

`.env` file khol ke apna `BOT_TOKEN` aur `CHANNEL_ID` daal do. Phir:

```bash
npm start
```

Server `http://localhost:3000` pe chalega.
- Admin panel: `http://localhost:3000/admin`
- Public API (jo app use karega): `http://localhost:3000/api/photos`

---

## Step 3 — Admin Panel Use Karo

Browser me `http://localhost:3000/admin` kholo:
1. Photo choose karo, caption/position (optional) daalo
2. "Upload to App" dabao
3. Backend photo ko turant tumhare Telegram channel me bhej dega, aur uska reference (`file_id`) SQLite me save kar dega
4. Neeche list me turant dikh jayegi, delete bhi kar sakte ho

---

## Step 4 — Android App Chalao

1. `android-app/` folder ko **Android Studio** me open karo ("Open an existing project")
2. Gradle sync hone do (pehli baar internet chahiye hoga dependencies download karne ke liye)
3. `ApiClient.kt` me `BASE_URL` check karo:
   - **Emulator** pe test kar rahe ho → `http://10.0.2.2:3000/` (already set hai)
   - **Real phone** pe test kar rahe ho → apne backend PC ka local IP daalo, e.g. `http://192.168.1.5:3000/` (phone aur PC same WiFi pe hone chahiye)
4. App run karo — jo bhi photos admin panel se upload ki hain, wo list me dikh jayengi

---

## Poora Flow (Summary)

```
Admin Panel (browser)
     │  photo upload
     ▼
Backend (Node.js + Express)
     │  sendPhoto()
     ▼
Telegram Bot API → Private Channel   (yahi tumhara "unlimited-ish" storage hai)
     │  file_id save hota hai
     ▼
SQLite (storage.db)  ← sirf ek chhoti si local file, koi cloud account nahi
     │
     ▼
Backend /api/photos endpoint (file_id → real download URL resolve karta hai)
     │
     ▼
Android App (Retrofit + Glide) → user ko photo dikhti hai
```

## Ek Bug Fix Kiya Gaya Hai

`AndroidManifest.xml` me `android:usesCleartextTraffic="true"` add kiya gaya hai. Bina isske Android 9+ (API 28+)
plain `http://` requests ko by default block kar deta — app chalta toh dikhta, lekin photos kabhi load nahi hoti
(silent failure, koi crash bhi nahi dikhta). Agar aage chal ke backend ko `https://` pe deploy karo (jaise Render/Railway),
toh ye line hata sakte ho, zaroorat nahi rahegi.

## APK Kaise Banao

Is sandbox environment me Android SDK/Gradle/internet nahi hai, isliye compiled `.apk` yahan se directly nahi ban sakti.
Do aasan tarike hain:

**Option A — Android Studio (sabse simple, ~2 min)**
1. `android-app/` folder Android Studio me open karo, Gradle sync hone do
2. Menu: `Build → Build Bundle(s)/APK(s) → Build APK(s)`
3. Build khatam hone pe "locate" link milega — APK yahan hogi: `app/build/outputs/apk/debug/app-debug.apk`

**Option B — GitHub Actions (bina apna PC use kiye, free)**
Ye repo me `.github/workflows/build-apk.yml` already included hai:
1. Is poore folder ko GitHub pe ek naye repo me push karo
2. GitHub khud-ba-khud APK build kar dega (Actions tab me build chalega, ~2-3 min)
3. Us workflow run ke "Artifacts" section se `app-debug-apk` download kar lo — usme `app-debug.apk` hogi

## Zaroori Baatein

- Per-file size limit: standard Bot API me upload ~50MB tak, isse zyada bade files ke liye local Bot API server chalana padega
- Ye ek unofficial use-case hai — Telegram isko officially "storage service" ke roop me promote nahi karta, production/large-scale app ke liye risk samajh ke use karo
- Backend ko production me deploy karte waqt (Render, Railway, VPS, etc.) `.env` file ko kabhi public repo me commit mat karna
- Agar users ki personal photos store kar rahe ho to unki privacy/consent ka dhyan rakhna
