// Agar backend alag server/domain pe host ho, to yahan uska full URL daal do
// e.g. const API_BASE = 'https://myserver.com';
const API_BASE = '';

const form = document.getElementById('uploadForm');
const statusMsg = document.getElementById('statusMsg');
const photoGrid = document.getElementById('photoGrid');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const file = document.getElementById('photoInput').files[0];
  const caption = document.getElementById('captionInput').value;
  const position = document.getElementById('positionInput').value;

  const formData = new FormData();
  formData.append('photo', file);
  formData.append('caption', caption);
  formData.append('position', position);

  statusMsg.textContent = 'Uploading...';
  try {
    const res = await fetch(`${API_BASE}/api/admin/upload`, {
      method: 'POST',
      body: formData,
    });
    const data = await res.json();
    if (data.success) {
      statusMsg.textContent = '✅ Upload ho gaya, app me dikhega';
      form.reset();
      loadPhotos();
    } else {
      statusMsg.textContent = '❌ ' + (data.error || 'Upload fail ho gaya');
    }
  } catch (err) {
    statusMsg.textContent = '❌ Network error — backend chal raha hai kya check karo';
  }
});

async function loadPhotos() {
  const res = await fetch(`${API_BASE}/api/admin/photos`);
  const photos = await res.json();
  photoGrid.innerHTML = '';
  photos.forEach((p) => {
    const card = document.createElement('div');
    card.className = 'photo-card';
    card.innerHTML = `
      <img src="${p.url}" alt="${p.caption || ''}">
      <p>${p.caption || '(no caption)'}</p>
      <small>position: ${p.position}</small><br>
      <button data-id="${p.id}">Delete</button>
    `;
    card.querySelector('button').addEventListener('click', () => deletePhoto(p.id));
    photoGrid.appendChild(card);
  });
}

async function deletePhoto(id) {
  if (!confirm('Ye photo app se hata dein?')) return;
  await fetch(`${API_BASE}/api/admin/photos/${id}`, { method: 'DELETE' });
  loadPhotos();
}

loadPhotos();
