package com.suhail.gitsync.data.repository

import com.suhail.gitsync.data.local.TokenStore
import com.suhail.gitsync.data.remote.DeviceFlowException
import com.suhail.gitsync.data.remote.GitHubDeviceAuthApi
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import retrofit2.HttpException
import java.io.IOException

/**
 * GitHub App expiring User Access Tokens: an access token (~8h) plus a
 * refresh token (~6mo) that GitHub ROTATES on every use — the old
 * access+refresh pair stops working the moment a new one is issued. This
 * class is the single place that reads/refreshes/saves that pair, used by
 * both [GitHubAuthRepository] and NetworkModule's interceptor/authenticator
 * so there is only one refresh code path, not two.
 */
class TokenRefresher(
    private val tokenStore: TokenStore,
    private val deviceAuthApi: GitHubDeviceAuthApi,
    private val clientId: String
) {
    private val mutex = Mutex()

    /**
     * Returns a token known to be valid right now, refreshing first if the
     * stored one is expired or close to it. Returns null if there is no
     * session at all (never connected / already disconnected) — callers
     * should not attempt the request in that case.
     *
     * If the App doesn't have expiring tokens enabled, GitHub never sends
     * an expiry, so [TokenStore.getAccessTokenExpiryMillis] is null and the
     * stored token is treated as always valid (nothing to refresh).
     */
    suspend fun ensureValidAccessToken(): String? {
        val token = tokenStore.getAccessToken() ?: return null
        val expiry = tokenStore.getAccessTokenExpiryMillis() ?: return token
        val fiveMinutesMs = 5 * 60 * 1000L
        if (System.currentTimeMillis() < expiry - fiveMinutesMs) return token
        return try {
            refreshAccessToken()
        } catch (e: DeviceFlowException.NoInternet) {
            // Temporary — keep the (soon-to-expire-or-expired) token rather
            // than disconnecting the user over a network blip; the actual
            // API call will surface its own real error if it truly fails.
            token
        }
    }

    /**
     * Performs exactly one refresh, safe to call concurrently — a second
     * caller that arrives while a refresh is already in flight waits for it
     * and reuses its result rather than racing GitHub's refresh-token
     * rotation (which would invalidate whichever request lost the race).
     *
     * Throws [DeviceFlowException.ExpiredToken] / [DeviceFlowException.AccessDenied]
     * (session truly gone — caller must require fresh Device Flow),
     * [DeviceFlowException.NoInternet] (temporary — caller may retry later
     * without disconnecting), or [DeviceFlowException.Other] for anything
     * else GitHub reports.
     */
    suspend fun refreshAccessToken(): String = mutex.withLock {
        // Another caller may have already refreshed while we waited for the lock.
        val currentToken = tokenStore.getAccessToken()
        val currentExpiry = tokenStore.getAccessTokenExpiryMillis()
        if (currentToken != null && currentExpiry != null && System.currentTimeMillis() < currentExpiry - 60_000L) {
            return@withLock currentToken
        }

        val refreshToken = tokenStore.getRefreshToken()
            ?: throw DeviceFlowException.ExpiredToken()

        val response = try {
            deviceAuthApi.refreshAccessToken(clientId, refreshToken)
        } catch (e: IOException) {
            throw DeviceFlowException.NoInternet()
        } catch (e: HttpException) {
            // A hard HTTP error (not GitHub's usual 200-with-error-field
            // shape) refreshing — treat as unrecoverable for this session.
            tokenStore.clear()
            throw DeviceFlowException.Other("Your GitHub session expired. Please reconnect.")
        }

        val newAccessToken = response.accessToken
        if (newAccessToken.isNullOrBlank()) {
            // bad_refresh_token / expired refresh token / revoked authorization / invalid_client, etc.
            tokenStore.clear()
            when (response.error) {
                "access_denied" -> throw DeviceFlowException.AccessDenied()
                else -> throw DeviceFlowException.ExpiredToken()
            }
        }

        val now = System.currentTimeMillis()
        // Save the new access+refresh pair (and their expiries) as ONE
        // atomic write — GitHub rotated the refresh token, so the old one
        // must never remain readable/usable after this point.
        tokenStore.saveTokenSet(
            accessToken = newAccessToken,
            refreshToken = response.refreshToken ?: refreshToken,
            accessTokenExpiryMillis = response.expiresIn?.let { now + it * 1000 },
            refreshTokenExpiryMillis = response.refreshTokenExpiresIn?.let { now + it * 1000 }
        )
        newAccessToken
    }
}
