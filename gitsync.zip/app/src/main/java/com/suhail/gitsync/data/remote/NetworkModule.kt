package com.suhail.gitsync.data.remote

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.suhail.gitsync.BuildConfig
import com.suhail.gitsync.data.local.TokenStore
import com.suhail.gitsync.data.repository.TokenRefresher
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.runBlocking
import okhttp3.Authenticator
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.Route
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object NetworkModule {

    private const val GITHUB_API_HOST = "api.github.com"
    private const val GITHUB_API_BASE_URL = "https://api.github.com/"
    private const val GITHUB_WEB_BASE_URL = "https://github.com/"

    val moshi: Moshi by lazy {
        Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    }

    fun isOnline(context: Context): Boolean {
        val cm = context.applicationContext
            .getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** Never logs headers (which would include the Authorization/Bearer token). */
    private fun loggingInterceptor(): HttpLoggingInterceptor {
        return HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BASIC
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }
    }

    /**
     * Proactive side of Task 11: obtains a token known to be valid (via
     * [TokenRefresher], refreshing first if needed) before attaching it,
     * rather than trusting whatever is currently stored. Falls back to the
     * raw stored token if [tokenRefresher] is absent (e.g. the lightweight
     * device-auth client, which never attaches a token at all since it
     * never applies to api.github.com).
     */
    private fun authInterceptor(tokenStore: TokenStore, tokenRefresher: TokenRefresher?) = okhttp3.Interceptor { chain ->
        val request = chain.request()
        val newRequest = if (request.url.host == GITHUB_API_HOST) {
            val token = try {
                if (tokenRefresher != null) runBlocking { tokenRefresher.ensureValidAccessToken() } else tokenStore.getAccessToken()
            } catch (e: Exception) {
                // Refresh failed here; fall through with whatever is stored
                // (possibly null/stale) — the Authenticator below is the
                // backstop that reacts if the request comes back 401.
                tokenStore.getAccessToken()
            }
            if (token.isNullOrBlank()) {
                request
            } else {
                request.newBuilder()
                    .addHeader("Authorization", "Bearer $token")
                    .addHeader("Accept", "application/vnd.github+json")
                    .addHeader("X-GitHub-Api-Version", "2022-11-28")
                    .build()
            }
        } else {
            request
        }
        chain.proceed(newRequest)
    }

    /**
     * Reactive side of Task 11: if a request still comes back 401 (clock
     * skew, server-side revocation, etc.), refresh exactly once and retry
     * the original request exactly once. Never loops — responseCount()
     * guards against retrying a request that has already been retried.
     */
    private fun authAuthenticator(tokenRefresher: TokenRefresher) = Authenticator { _: Route?, response: Response ->
        if (responseCount(response) >= 2) return@Authenticator null
        if (response.request.header("Authorization") == null) return@Authenticator null
        val newToken = try {
            runBlocking { tokenRefresher.refreshAccessToken() }
        } catch (e: Exception) {
            return@Authenticator null
        }
        response.request.newBuilder()
            .header("Authorization", "Bearer $newToken")
            .build()
    }

    private fun responseCount(response: Response): Int {
        var result = 1
        var prior = response.priorResponse
        while (prior != null) {
            result++
            prior = prior.priorResponse
        }
        return result
    }

    private fun okHttpClient(tokenStore: TokenStore, tokenRefresher: TokenRefresher?): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .addInterceptor(authInterceptor(tokenStore, tokenRefresher))
            .addInterceptor(loggingInterceptor())
        if (tokenRefresher != null) {
            builder.authenticator(authAuthenticator(tokenRefresher))
        }
        return builder.build()
    }

    fun createGitHubApi(context: Context, tokenStore: TokenStore, tokenRefresher: TokenRefresher? = null): GitHubApi {
        val retrofit = Retrofit.Builder()
            .baseUrl(GITHUB_API_BASE_URL)
            .client(okHttpClient(tokenStore, tokenRefresher))
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        return retrofit.create(GitHubApi::class.java)
    }

    fun createDeviceAuthApi(tokenStore: TokenStore): GitHubDeviceAuthApi {
        // Uses its own OkHttpClient (no auth header needed/available yet)
        // but still wants a longer read timeout to be safe with slow networks.
        val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor())
            .build()
        val retrofit = Retrofit.Builder()
            .baseUrl(GITHUB_WEB_BASE_URL)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        return retrofit.create(GitHubDeviceAuthApi::class.java)
    }
}
