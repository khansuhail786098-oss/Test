package com.suhail.gitsync

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.suhail.gitsync.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    // Must be called before super.onCreate() — shows the Android system
    // splash (Theme.Splash) instead of a blank/grey window until the first
    // Compose frame is drawn, then hands off to the normal app theme.
    installSplashScreen()
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        GitSyncApp()
      }
    }
  }
}
