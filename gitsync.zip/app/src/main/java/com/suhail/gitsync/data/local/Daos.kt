package com.suhail.gitsync.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects WHERE accountLogin = :accountLogin ORDER BY lastPushedAtMillis DESC")
    fun observeForAccount(accountLogin: String): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getById(id: String): ProjectEntity?

    @Upsert
    suspend fun upsert(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteById(id: String)

    /**
     * One-time adoption of pre-account-scoping rows (accountLogin = '',
     * left behind by the Room migration that added this column) by
     * whichever account first connects after the update — preserves that
     * data instead of it becoming permanently invisible or being deleted.
     */
    @Query("UPDATE projects SET accountLogin = :accountLogin WHERE accountLogin = ''")
    suspend fun claimUnscopedRows(accountLogin: String)
}

@Dao
interface FileRecordDao {
    @Query("SELECT * FROM file_records WHERE projectId = :projectId")
    suspend fun getForProject(projectId: String): List<FileRecordEntity>

    @Upsert
    suspend fun upsertAll(records: List<FileRecordEntity>)

    @Query("DELETE FROM file_records WHERE projectId = :projectId AND path IN (:paths)")
    suspend fun deleteByPaths(projectId: String, paths: List<String>)

    @Query("DELETE FROM file_records WHERE projectId = :projectId")
    suspend fun deleteForProject(projectId: String)

    /** Replace the entire snapshot for a project atomically. */
    @Transaction
    suspend fun replaceSnapshot(projectId: String, records: List<FileRecordEntity>) {
        deleteForProject(projectId)
        upsertAll(records)
    }
}

@Dao
interface RecentFolderDao {
    @Query("SELECT * FROM recent_folders WHERE accountLogin = :accountLogin ORDER BY lastUsedAtMillis DESC LIMIT 10")
    fun observeRecentForAccount(accountLogin: String): Flow<List<RecentFolderEntity>>

    @Upsert
    suspend fun upsert(folder: RecentFolderEntity)

    @Query("DELETE FROM recent_folders WHERE treeUri = :treeUri")
    suspend fun deleteByUri(treeUri: String)

    /** Same one-time adoption as ProjectDao.claimUnscopedRows, for recent folders. */
    @Query("UPDATE recent_folders SET accountLogin = :accountLogin WHERE accountLogin = ''")
    suspend fun claimUnscopedRows(accountLogin: String)
}
