package com.suhail.gitsync.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.migration.Migration

/**
 * Adds account scoping (Task 6): projects and recent folders are now tied
 * to the GitHub account (login) that created them, so switching accounts
 * shows only that account's data instead of whatever was last connected.
 * This is additive (ALTER TABLE ... ADD COLUMN) and keeps every existing
 * row — nothing is deleted. Pre-existing rows get an empty accountLogin,
 * which GitSyncRepository "claims" for whichever account first connects
 * after this update (see ProjectDao.claimUnscopedProjects /
 * RecentFolderDao.claimUnscopedFolders), rather than losing that data.
 */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE projects ADD COLUMN accountLogin TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE projects ADD COLUMN isSingleFile INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE recent_folders ADD COLUMN accountLogin TEXT NOT NULL DEFAULT ''")
    }
}

@Database(
    entities = [ProjectEntity::class, FileRecordEntity::class, RecentFolderEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun fileRecordDao(): FileRecordDao
    abstract fun recentFolderDao(): RecentFolderDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "gitsync.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build().also { INSTANCE = it }
            }
        }
    }
}
