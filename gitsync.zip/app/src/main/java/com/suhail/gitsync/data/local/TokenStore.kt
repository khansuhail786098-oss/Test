package com.suhail.gitsync.data.local

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores the GitHub access/refresh tokens (and a couple of small,
 * non-sensitive account fields used to restore the UI instantly on app
 * start) using an EncryptedSharedPreferences file whose encryption key
 * lives in the Android Keystore.
 *
 * Tokens NEVER touch plain SharedPreferences, are never logged, and are
 * wiped completely on [clear] (called from Disconnect GitHub).
 */
class TokenStore(context: Context) {

    private val appContext = context.applicationContext

    private val prefs: SharedPreferences by lazy { buildEncryptedPrefs() }

    private fun buildEncryptedPrefs(): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                appContext,
                PREFS_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // If the Keystore-backed file is corrupted (e.g. after a Keystore
            // reset on some OEM ROMs) drop it and start clean rather than
            // crashing the app on every launch. We deliberately do not log
            // the exception message, as some OEM implementations include
            // partial key material in it.
            Log.w(TAG, "Recreating encrypted token store after failure")
            appContext.deleteSharedPreferences(PREFS_FILE_NAME)
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                appContext,
                PREFS_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
    }

    fun getAccessToken(): String? = prefs.getString(KEY_ACCESS_TOKEN, null)

    fun hasAccessToken(): Boolean = !getAccessToken().isNullOrBlank()

    fun getRefreshToken(): String? = prefs.getString(KEY_REFRESH_TOKEN, null)

    /** Null means "the App doesn't have expiring tokens enabled" (token never expires). */
    fun getAccessTokenExpiryMillis(): Long? =
        if (prefs.contains(KEY_ACCESS_TOKEN_EXPIRY)) prefs.getLong(KEY_ACCESS_TOKEN_EXPIRY, 0L) else null

    fun getRefreshTokenExpiryMillis(): Long? =
        if (prefs.contains(KEY_REFRESH_TOKEN_EXPIRY)) prefs.getLong(KEY_REFRESH_TOKEN_EXPIRY, 0L) else null

    /**
     * Saves a fresh access token (initial Device Flow success, or a
     * refresh) as ONE atomic write, along with its refresh token and both
     * expiry timestamps. GitHub ROTATES refresh tokens: using this instead
     * of separate saveAccessToken()/saveRefreshToken() calls means there is
     * never a window where the old refresh token is readable after the new
     * access token has already been saved (or vice versa).
     */
    fun saveTokenSet(
        accessToken: String,
        refreshToken: String?,
        accessTokenExpiryMillis: Long?,
        refreshTokenExpiryMillis: Long?
    ) {
        val editor = prefs.edit().putString(KEY_ACCESS_TOKEN, accessToken)
        if (refreshToken != null) editor.putString(KEY_REFRESH_TOKEN, refreshToken) else editor.remove(KEY_REFRESH_TOKEN)
        if (accessTokenExpiryMillis != null) editor.putLong(KEY_ACCESS_TOKEN_EXPIRY, accessTokenExpiryMillis) else editor.remove(KEY_ACCESS_TOKEN_EXPIRY)
        if (refreshTokenExpiryMillis != null) editor.putLong(KEY_REFRESH_TOKEN_EXPIRY, refreshTokenExpiryMillis) else editor.remove(KEY_REFRESH_TOKEN_EXPIRY)
        editor.apply()
    }

    /**
     * The Client ID of the GitHub App that issued the currently stored
     * token. A GitHub App user-access-token is only meaningful for the
     * specific App (and its installation/permissions) that minted it — it
     * is not portable across GitHub Apps. Recording this lets us detect a
     * token left over from a previous/old GitHub App (e.g. after rotating
     * Client IDs during development) and refuse to reuse it.
     */
    fun saveClientId(clientId: String) {
        prefs.edit().putString(KEY_CLIENT_ID, clientId).apply()
    }

    fun getStoredClientId(): String? = prefs.getString(KEY_CLIENT_ID, null)

    /**
     * The GitHub login (not sensitive — just a username) that was connected
     * last time. Used to scope local Projects/Recent Folders correctly on
     * app restart before the live account is re-fetched.
     */
    fun saveUsername(login: String) {
        prefs.edit().putString(KEY_USERNAME, login).apply()
    }

    fun getStoredUsername(): String? = prefs.getString(KEY_USERNAME, null)

    /** Removes the tokens and all cached account fields. Called on Disconnect and on unrecoverable refresh failure. */
    fun clear() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val TAG = "TokenStore"
        private const val PREFS_FILE_NAME = "gitsync_secure_prefs"
        private const val KEY_ACCESS_TOKEN = "github_access_token"
        private const val KEY_REFRESH_TOKEN = "github_refresh_token"
        private const val KEY_ACCESS_TOKEN_EXPIRY = "github_access_token_expiry"
        private const val KEY_REFRESH_TOKEN_EXPIRY = "github_refresh_token_expiry"
        private const val KEY_CLIENT_ID = "github_client_id"
        private const val KEY_USERNAME = "github_username"
    }
}
