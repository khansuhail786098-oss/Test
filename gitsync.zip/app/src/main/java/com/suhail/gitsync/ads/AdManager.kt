package com.suhail.gitsync.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Google's own published TEST interstitial ad unit ID — safe to ship, never a real production ID. */
const val TEST_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

/** Google's own published TEST banner ad unit ID — safe to ship, never a real production ID. */
const val TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/9214589741"

enum class AdLoadState { NOT_LOADED, LOADING, READY, FAILED }

/**
 * Owns exactly one interstitial ad instance for the "Push to GitHub" ad
 * gate. Preloads proactively (so it's usually already ready by the time the
 * user taps Push) without blocking app startup — [MobileAds.initialize] and
 * every load call here return immediately and do their work on Google's own
 * background threads.
 *
 * Never leaks an Activity: [show] only ever receives one transiently as a
 * parameter, never stored as a field.
 */
class AdManager(private val context: Context) {

    private val _state = MutableStateFlow(AdLoadState.NOT_LOADED)
    val state: StateFlow<AdLoadState> = _state

    @Volatile private var interstitialAd: InterstitialAd? = null
    @Volatile private var sdkInitialized = false

    fun initializeSdk() {
        if (sdkInitialized) return
        sdkInitialized = true
        MobileAds.initialize(context.applicationContext) { /* no-op; ready to serve requests */ }
    }

    fun isReady(): Boolean = interstitialAd != null && _state.value == AdLoadState.READY

    /** Safe to call repeatedly — a no-op while already loading or already holding a ready ad. */
    fun preload() {
        if (interstitialAd != null || _state.value == AdLoadState.LOADING) return
        initializeSdk()
        _state.value = AdLoadState.LOADING
        InterstitialAd.load(
            context.applicationContext,
            TEST_INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    _state.value = AdLoadState.READY
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    _state.value = AdLoadState.FAILED
                }
            }
        )
    }

    /**
     * Shows the preloaded interstitial. [onCompleted] fires only after the
     * user dismisses it (never before) — that's the signal the gated action
     * (the GitHub push) is allowed to run. [onUnavailable] fires if there
     * was nothing to show or it failed to display; the caller must NOT
     * proceed with the gated action in that case.
     */
    fun show(activity: Activity, onCompleted: () -> Unit, onUnavailable: () -> Unit) {
        val ad = interstitialAd
        if (ad == null) {
            _state.value = AdLoadState.FAILED
            onUnavailable()
            return
        }
        interstitialAd = null // an InterstitialAd instance can only ever be shown once
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                _state.value = AdLoadState.NOT_LOADED
                preload() // have the next one ready ahead of time
                onCompleted()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                _state.value = AdLoadState.NOT_LOADED
                preload()
                onUnavailable()
            }
        }
        ad.show(activity)
    }
}
